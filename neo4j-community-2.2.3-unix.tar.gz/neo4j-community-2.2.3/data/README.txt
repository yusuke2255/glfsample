Neo4j Data
=======================================

This directory contains all live data managed by this server, including
database files, logs, and other "live" files.
